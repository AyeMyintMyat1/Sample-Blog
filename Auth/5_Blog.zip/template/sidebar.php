      <!-- SideBar start -->
      <div class="col-12  col-lg-3 col-xl-2  vh-100 sidebar ">
        <div class="d-flex align-items-center justify-content-between my-2 nav-top">
          <div class="d-flex align-items-center">
            <span class="btn btn-primary"><i class="feather-shopping-bag" style="font-size: 35px;"></i></span>
            <span class="h3 text-primary text-uppercase mb-0 ms-1">My Shop</span>
          </div>
          <button class="btn btn-light my-2 p-0 float-end d-block d-lg-none" id="hide-sidebar-btn"> <i class="feather-x text-danger" style="font-size:45px;"></i>
          </button>
        </div>
        <div class="nav-menu">
          <ul>
            <li class="menu-item">
              <a href="<?php echo $url; ?>/index.php" class="menu-item-link ">
                <span><i class="feather-home"></i>
                  Dashboard</span>
              </a>
            </li>
            <li class="menu-spacer"></li>
            <li class="menu-title">
              <h3>Manage Item</h3>
            </li>
            <li class="menu-item">
              <a href="<?php echo $url; ?>/add_item.php" class="menu-item-link">
                <span><i class="feather-plus-circle"></i>
                  Add Item</span>
              </a>
            </li>
            <li class="menu-item">
              <a href="<?php echo $url; ?>/item_list.php" class="menu-item-link">
                <span><i class="feather-list"></i>
                  Item List</span>
                <span class="badge rounded-1 bg-white text-primary opacity-75 shadow-sm">75</span>
              </a>
            </li>
            <li class="menu-spacer"></li>
            <li class="menu-item">
              <a href="<?php echo $url; ?>/category_create.php" class="menu-item-link">
                <span><i class="feather-plus-circle"></i>
                  Add Category</span>
              </a>
            </li>
            <li class="menu-item">
              <a href="<?php echo $url; ?>/category_read.php" class="menu-item-link">
                <span><i class="feather-plus-circle"></i>
                  Category List</span>
              </a>
            </li>
            <li class="menu-spacer"></li>
            <li class="menu-item">
              <a href="<?php echo $url; ?>/logout.php" class="btn btn-danger w-100">
                <i class="feather-unlock"></i>
                LogOut
              </a>
            </li>
          </ul>
        </div>
      </div>
      <!-- SideBar end -->