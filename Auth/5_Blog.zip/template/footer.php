<script src="<?php echo $url;?>/assets/vendor/jquery.min.js"></script>
<script>
  //active
let currentPage=window.location.href;
$('.menu-item-link').each(function(){
  let links=$(this).attr('href');
  if(currentPage==links){
    $(this).addClass('active');
  }
});
</script>
<script src="<?php echo $url;?>/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo $url;?>/assets/vendor/bootstrap/js/bootstrap.min.js"></script>
  <script src="<?php echo $url;?>/assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
  <script src="<?php echo $url;?>/assets/vendor/popper.min.js"></script>
  <script src="<?php echo $url;?>/assets/vendor/Waypoint/lib/jquery.waypoints.min.js"></script>
  <script src="<?php echo $url;?>/assets/vendor/Counter-Up-master/jquery.counterup.min.js"></script>
  <script src="<?php echo $url;?>/assets/vendor/chart.js/dist/chart.js"></script>
  <script src="<?php echo $url;?>/assets/vendor/chart.js/dist/chart.min.js"></script>
  <script src="<?php echo $url;?>/assets/JS/app.js"></script>
  <script src="<?php echo $url;?>/assets/JS/dashboard.js"></script>
</body>

</html>