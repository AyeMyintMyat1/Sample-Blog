<?php
//common start
function alert($data,$color='danger'){
 return "<p class='alert alert-$color'>$data</p>";
}
function runQuery($sql){
if(mysqli_query(con(),$sql)){
 return true;
}else{
 die("Insert Fail");
}
}
function redirect($l){
  header("Location:$l");
}

//common end
//Auth start
function register(){
 $name=$_POST['name'];
 $email=$_POST['email'];
 $password=$_POST['password'];
 $cpassword=$_POST['cpassword'];
 if($password==$cpassword){
  $spassword=password_hash($password,PASSWORD_DEFAULT);
$sql="INSERT INTO users(name,email,password) VALUES('$name','$email','$spassword')";
 if(runQuery($sql)){
  redirect("login.php");
 }
 }else{
 return alert("password don't match.");
 }
}

function login(){
  $email=$_POST['email'];
  $password=$_POST['password'];
  $sql="SELECT * FROM users WHERE email='$email'";
  $query=mysqli_query(con(),$sql);
  $row=mysqli_fetch_assoc($query);
if(!$row){
  return alert("Email and Password do not match");
}else{
if(!password_verify($password,$row['password'])){
  return alert("Email and Password do not match");
    }else{
      session_start();
      $_SESSION['user']=$row;
      redirect("dashboard.php");
    }
}
}
//Auth end
