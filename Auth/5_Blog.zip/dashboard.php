<?php require_once "core/auth.php" ?>
<?php include "template/header.php"; ?>
    <!-- Content Area start -->
   <h1>Dashboard Page</h1>
   <pre>
   <?php print_r($_SESSION['user']);?>
    <!-- Content Area end -->
   </div>
  </div>
 </section>
  <?php include "template/footer.php"; ?>