<?php 
function a(){
 static $a=0;
 echo ++$a."<br>";
}
a();
a();
a();
?>